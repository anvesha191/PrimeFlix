// replace below firebase config with your own

const firebaseConfig = {
    apiKey: "AIzaSyCEy6YUeAvjOmRARvTRdfGeL8RJDzs8U7A",
    authDomain: "netflix-clone-d1fa8.firebaseapp.com",
    projectId: "netflix-clone-d1fa8",
    storageBucket: "netflix-clone-d1fa8.appspot.com",
    messagingSenderId: "1080602120235",
    appId: "1:1080602120235:web:29e7c05415df6c1cd65a6e"
  };



// craete a/c on themoviedb.org and replace access token below


const TMDB_Access_Key="eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlZTNlNzczZDIwY2M2Y2NhNWQ4YWVjMjQzNTdlNDc1ZCIsInN1YiI6IjY2MjIyMDFhYWUzODQzMDE4NzJhNTJjMiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.vPDW2QwNr9hIRdOvJx_x8hbHnDYZGHMtnZwfkqb3J8U";


  export {firebaseConfig, TMDB_Access_Key};